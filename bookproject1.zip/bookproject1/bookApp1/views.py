from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from bookApp1.forms import UserAdminCreationForm,CreateBookForm
from bookApp1.models import CreateBook

# Create your views here.
def home_view(request):
    return render(request,'bookApp1/home.html')

def signup_view(request):
    form=UserAdminCreationForm()
    if(request.method=="POST"):
        form=UserAdminCreationForm(request.POST)
        if(form.is_valid()):
            form.save()
            return HttpResponseRedirect('accounts/login')
    return render(request,'bookApp1/signup.html',{'form':form})

@login_required
def createbook_view(request):
    form=CreateBookForm()
    if(request.method=="POST"):
        form=CreateBookForm(request.POST)
        if(form.is_valid()):
            form.save()
            return HttpResponseRedirect('/display_books')
    return render(request,'bookApp1/createbook_form.html',{'form':form})

@login_required
def displaybook_view(request):
    book_info=CreateBook.objects.all()
    return render(request,'bookApp1/displaybook_list.html',{'book_info':book_info})

@login_required
def delete_book_view(request,id):
    book=CreateBook.objects.get(id=id)
    book.delete()
    return redirect('/display_books')


def update_book_view(request,id):
    book=CreateBook.objects.get(id=id)
    if(request.method=="POST"):
        form=CreateBookForm(request.POST,instance=book)
        if(form.is_valid()):
            form.save()
            return redirect('/display_books')
    #form=book

    return render(request,'bookApp1/updatebook_form.html',{'book':book})
