from django.apps import AppConfig


class Bookapp1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bookApp1'
